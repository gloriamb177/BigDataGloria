CREATE TABLE Datos (
    id BIGINT PRIMARY KEY,
    listing_url VARCHAR(255),
    name VARCHAR(255),
    host_id BIGINT,
    host_name VARCHAR(100),
    host_is_superhost CHAR(1), -- 't' o 'f'
    neighbourhood_cleansed VARCHAR(100),
    latitude FLOAT,
    longitude FLOAT,
    room_type VARCHAR(50),
    accommodates INT,
    bedrooms FLOAT, -- Se usa float porque el archivo contiene valores como 3.0, 1.0
    beds FLOAT,
    price DECIMAL(10,2),
    number_of_reviews INT,
    review_scores_rating FLOAT,
    region_origen VARCHAR(100),
    has_no_reviews BIT, -- 0 o 1
    bathrooms_num FLOAT
);
GO