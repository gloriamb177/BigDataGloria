CREATE OR ALTER PROCEDURE sp_CargarAirbnbCSV
    @RutaArchivo VARCHAR(500)
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        DECLARE @SQL NVARCHAR(MAX);
        
        SET @SQL = N'
        BULK INSERT Datos
        FROM ''' + @RutaArchivo + '''
        WITH (
            FIRSTROW = 2,
            FORMAT = ''CSV'',         -- <--- Activa el formateador oficial de CSV
            FIELDTERMINATOR = '','',
            ROWTERMINATOR = ''\n'',
            TABLOCK,
            CODEPAGE = ''65001''
        );';

        EXEC sp_executesql @SQL;
        PRINT 'Carga masiva completada con éxito.';
    END TRY
    BEGIN CATCH
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
        DECLARE @ErrorState INT = ERROR_STATE();
        RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;
GO

--EXEC sp_CargarAirbnbCSV @RutaArchivo = 'C:\Datos\airbnb_espana_clean.csv';

--SELECT * FROM [Airbnb].[dbo].[Datos]